export type cost ={
    date: string;
    cost_head: string;
    cost: Number;
}